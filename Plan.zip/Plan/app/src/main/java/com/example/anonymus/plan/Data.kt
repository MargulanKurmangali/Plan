package com.example.anonymus.plan

/**
 * Created by Anonymus on 14.02.2018.
 */
class Data {
}